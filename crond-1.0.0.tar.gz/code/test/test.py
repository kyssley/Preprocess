# -*- coding: utf8 -*-
import time

if __name__ == '__main__':
    open("../../log/py.log","a").write(str(time.time())+"\n")